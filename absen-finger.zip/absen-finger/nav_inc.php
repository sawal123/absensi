<nav class="navbar navbar-expand-custom navbar-mainbg">
    <div class="container">
        <a class="navbar-brand navbar-logo" href="#">SMP DARUL ISTIQLAL MARINDAL 1</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars text-white"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent" ">
                <ul class=" navbar-nav sel">
            <div class=" hori-selector">
                <div class="left"></div>
                <div class="right"></div>
            </div>
            <li class="nav-item long">
                <a class="nav-link a" href="data-siswa.php" href="javascript:void(0);"><i class="fa-solid fa-folder"></i>Data Siswa</a>
            </li>
            <li class="nav-item long">
                <a class="nav-link a" href="tambah-data.php" href="javascript:void(0);"><i class="fa-solid fa-user-plus"></i></i>Tambah Data</a>
            </li>
            <li class="nav-item log">
                <a class="nav-link a" href="javascript:void(0);"><i class="fa-solid fa-power-off"></i>Logout</a>
            </li>

            </ul>
        </div>
    </div>
</nav>