<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
                <i class="typcn typcn-device-desktop menu-icon"></i>
                <span class="menu-title">Dashboard</span>
                <div class="badge badge-danger">new</div>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link"  href="tambah-data.php">
                <i class="typcn typcn-user-add-outline menu-icon"></i>
                <span class="menu-title">User Pages</span>
                <!-- <i class="menu-arrow"></i> -->
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link"  href="setting.php">
                <i class="typcn typcn-cog-outline menu-icon"></i>
                <span class="menu-title">Setting</span>
                <!-- <i class="menu-arrow"></i> -->
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link"  href="config/logout.php">
                <i class="typcn typcn-power menu-icon"></i>
                <span class="menu-title">Log Out</span>
                <!-- <i class="menu-arrow"></i> -->
            </a>
        </li>

    </ul>
</nav>